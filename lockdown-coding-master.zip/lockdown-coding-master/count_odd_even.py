// Given a list of numbers, write a Python program to count Even and Odd numbers in a List.
# list of numbers 
#list can be changed according to user
list1 = [10, 21, 4, 45, 66, 93, 1] 
  
even_count, odd_count = 0, 0
  
# iterating each number in list 
for num in list1: 
      
    # checking condition 
    if num % 2 == 0: 
        even_count += 1
  
    else: 
        odd_count += 1
          
print("Even numbers in the list: ", even_count) 
print("Odd numbers in the list: ", odd_count) 
